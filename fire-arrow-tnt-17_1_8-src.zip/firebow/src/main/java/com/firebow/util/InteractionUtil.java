package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * InteractionUtil v4 — split pattern:
 *
 * RAIL → 2-tick Grim-safe (rotation must precede movement packet):
 *   prepareRailPlacement() → beforeSync applies rotation → executePending() tick after
 *
 * CART → direct same-tick (no rotation check by Grim for entity placement on rail):
 *   placeCartDirect() → interactBlock immediately, no rotation needed
 *
 * Lý do tách: HT1 insta cart đặt cart NGAY sau khi rail confirm,
 * không có 1-tick rotation delay. Grim không strict-check rotation
 * khi spawn entity (minecart) lên block đã tồn tại — chỉ check khi đặt block mới.
 */
public final class InteractionUtil {
    private InteractionUtil() {}

    // Pending rail interact state (2-tick pattern)
    private static volatile BlockPos pendingPos  = null;
    private static volatile int      pendingSlot = -1;
    private static volatile int      savedSlot   = -1;

    // ─── Rail: 2-tick pattern ────────────────────────────────────────────────

    /**
     * Stage 1: Chuẩn bị đặt rail.
     * Rotation được apply trong beforeSync cùng tick này,
     * interact xảy ra tick sau qua executePending().
     */
    /**
     * Stage 1: Lưu railPos + slot. KHÔNG tính rotation ở đây.
     * Rotation tính ở executePending (tick N+1) khi eyePos là vị trí thực tại thời điểm interact.
     * Bug cũ: rotation tính ở tick N → eyePos dịch chuyển khi player đang chạy
     *         → Grim raycast tick N+1 từ eyePos mới → trượt khỏi block → ghost rail.
     */
    /**
     * Stage 1: Tính rotation từ eyePos tick N+1 (predict) để nhất quán với
     * movement packet tick N (beforeSync dùng cùng rotation này).
     *
     * eyePos tick N+1 = eyePos tick N + velocity tick N
     * Grim raycast từ eyePos movement packet → phải trúng block.
     * Dùng cùng 1 rotation cho cả movement packet (tick N) và interactBlock (tick N+1).
     */
    public static void prepareRailPlacement(MinecraftClient mc, BlockPos railPos, int railSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        pendingPos  = railPos;
        pendingSlot = railSlot;
        savedSlot   = p.getInventory().selectedSlot;

        // Predict eyePos tick N+1 = eyePos + velocity (với gravity nếu đang bay)
        // Player gravity: -0.08 mỗi tick khi không onGround, drag 0.98
        Vec3d eye = p.getEyePos();
        Vec3d vel = p.getVelocity();
        double vy = p.isOnGround() ? vel.y : (vel.y - 0.08) * 0.98;
        Vec3d eyeNext = eye.add(vel.x, vy, vel.z);

        BlockPos groundPos = railPos.down();
        Vec3d    hitVec    = RotationUtil.calcHitVec(groundPos, Direction.UP);

        // Tính rotation từ eyePos tick N+1 → dùng cho cả movement packet và interact
        float[]  rot = RotationUtil.calcRotationFromEye(eyeNext, hitVec);
        RotationUtil.setPending(p, rot);
    }

    /**
     * Stage 2: Dùng rotation đã tính từ tick N (không tính lại).
     * Movement packet tick N đã mang rotation này → interact packet tick N+1 cũng vậy → consistent.
     */
    public static boolean executePending(MinecraftClient mc) {
        if (pendingPos == null) return false;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) { clearPending(); return false; }

        BlockPos pos      = pendingPos;
        int      slot     = pendingSlot;
        int      origSlot = savedSlot;

        pendingPos  = null;
        pendingSlot = -1;
        savedSlot   = -1;

        BlockPos groundPos = pos.down();
        Vec3d    hitVec    = RotationUtil.calcHitVec(groundPos, Direction.UP);

        // Apply rotation tick N (đã set ở prepareRailPlacement, nhất quán với movement packet)
        RotationUtil.applyRawNow(p);

        p.getInventory().selectedSlot = slot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, groundPos, false));
        p.getInventory().selectedSlot = origSlot;

        RotationUtil.restoreAfterInteract(p);
        return true;
    }

    // ─── Cart: direct same-tick ───────────────────────────────────────────────

    /**
     * Đặt cart trực tiếp — không cần 2-tick rotation.
     * Grim không check rotation khi spawn entity lên rail.
     * Gọi ngay khi rail confirmed exist trong world.
     *
     * @return true nếu interact packet đã gửi
     */
    public static boolean placeCartDirect(MinecraftClient mc, BlockPos railPos, int cartSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;

        // Reach check trước — Grim validate reach của cart cũng như block
        if (!inReach(p, railPos)) return false;

        Vec3d   hitVec   = RotationUtil.calcHitVec(railPos, Direction.UP);
        float[] rot      = RotationUtil.calcRotation(p, hitVec);
        float   savedYaw = p.getYaw();
        float   savedPit = p.getPitch();

        p.setYaw(rot[0]); p.setPitch(rot[1]);
        p.headYaw = rot[0]; p.bodyYaw = rot[0];

        int origSlot = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = cartSlot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, railPos, false));
        p.getInventory().selectedSlot = origSlot;

        p.setYaw(savedYaw); p.setPitch(savedPit);
        p.headYaw = savedYaw; p.bodyYaw = savedYaw;
        return true;
    }

    public static boolean hasPending() { return pendingPos != null; }

    public static void clearPending() {
        pendingPos  = null;
        pendingSlot = -1;
        savedSlot   = -1;
        RotationUtil.restoreAfterInteract(MinecraftClient.getInstance().player);
    }

    public static boolean inReach(ClientPlayerEntity p, BlockPos pos) {
        return inReachFrom(p.getEyePos(), pos);
    }

    /** Check reach từ eyePos tuỳ ý — dùng để validate với predicted eyePos tick N+1. */
    public static boolean inReachFrom(Vec3d eyePos, BlockPos pos) {
        return eyePos.squaredDistanceTo(Vec3d.ofCenter(pos)) <= 4.5 * 4.5;
    }
}
